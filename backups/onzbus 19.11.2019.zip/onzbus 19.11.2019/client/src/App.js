import React, {Fragment} from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom'
import Header from "./components/Layout/header.js"
import schoolHome from './components/school/schoolHome'

function App() {
  return (
    <Router>
      <Fragment>
            <Header/>
      </Fragment>         
      <Route exact path = "/school/schoolHome" component = {schoolHome}/>
    
    </Router>
  );
  
}

export default App;
