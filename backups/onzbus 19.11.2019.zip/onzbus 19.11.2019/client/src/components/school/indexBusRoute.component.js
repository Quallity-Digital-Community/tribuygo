import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import CreateBusRoute from './createBusRoute.component';
import React, { Component } from 'react';
import axios from 'axios';
import TableRow from './TableRowBus';

export default class IndexBusRoute extends Component {

  constructor(props) {
      super(props);
      this.state = {business: []};
    }
    componentDidMount(){
      axios.get('http://172.105.92.110:4000/getBusListTest')
        .then(response => {
          this.setState({ business: response.data });
        })
        .catch(function (error) {
          console.log(error);
        })
    }

/*    componentDidUpdate(prevProps, prevState) {
      console.log("Current: ",this.state.business);
      console.log("Previous: ", prevState.business);
      if( JSON.stringify(prevState.business) !== JSON.stringify(this.state.business))
      {
          axios.get("http://172.105.92.110:4000/getBusListTest")
          .then(response => {
            console.log(response.data);
            this.setState({ business: response.data });
          })
          .catch(function (error) {
          console.log(error);
          })
      }
      else{console.log("In ELSA");}
      }
*/      
    tabRow(){
      return this.state.business.map(function(object, i){
          return <TableRow obj={object} key={i} />;
      });
    }

    render() {
      return (
        <Router>
        <div>
        <Link to= {"/createBusRoute"} className="btn btn-primary btn-lg m-6">Add Bus Route</Link>
        </div>
        <div>
          <h4 align="center">Buses List</h4>
          <table className="table table-striped" style={{ marginTop: 1 }}>
            <thead>
              <tr>
                <th>Bus Number</th>
                <th colSpan="2">Action</th>
              </tr>
            </thead>
            <tbody>
              { this.tabRow() }
            </tbody>
          </table>
        </div>
        <Switch>
        <Route exact path='/createBusRoute' component={ CreateBusRoute } />
        </Switch>  
        </Router>
      );
    }
  }